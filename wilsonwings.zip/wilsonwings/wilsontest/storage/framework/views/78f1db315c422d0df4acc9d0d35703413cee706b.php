

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
			<div class="page-content">
		<!--breadcrumb-->
<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    
                    
                </div>
                <!--end breadcrumb-->		  
				<div class="card">
					<div class="card-body">
						<div class="d-lg-flex align-items-center mb-4 gap-3">
						</div>
              			
            				<form action="<?php echo e(route('search_results')); ?>" id="custom_form" method="post" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>
								<div class="row">	
									<div class="col-md-5 mt-3">
										<label for="title" class="form-label">Title*</label>
										<input type="text"    class="form-control  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  id="title" name="title" value="<?php if(!empty($title)): ?><?php echo e($title); ?> <?php endif; ?>"  />
										<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
										</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									
									<div class="col-md-2 mt-5">
										<label for="title" class="form-label"></label>
										<button type="submit" id="search" class="from-control btn btn-dark">Submit</button>
									</div>
								</div>
							</form>
							<div class="table-responsive" id="total_order">
								<h1 class="text-center mt-5 mb-5">Posts</h1>
							
								<table class="table mb-0" id="example2">
									<thead class="table-light">
										<tr>
											<th>No#</th>
											<th>Title</th>
											<th>Content</th>
											
										</tr>
									</thead>
									<tbody>
										<?php $i = 0;?>
										
										<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php ++$i; ?>
											<tr>
												<td><?php echo e($i); ?></td>
												
												<td><?php echo e($data->title); ?></td>
												<td><?php echo e($data->content); ?></td>
											</tr>
										
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
									</tbody>
									
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wilsonwings\wilsontest\resources\views/admin/search.blade.php ENDPATH**/ ?>